class Food < ActiveRecord::Base
end
