class ReprodutionsController < ApplicationController
  before_action :set_reprodution, only: [:show, :edit, :update, :destroy]

  # GET /reprodutions
  # GET /reprodutions.json
  def index
    @reprodutions = Reprodution.all
  end

  # GET /reprodutions/1
  # GET /reprodutions/1.json
  def show
  end

  # GET /reprodutions/new
  def new
    @reprodution = Reprodution.new
  end

  # GET /reprodutions/1/edit
  def edit
  end

  # POST /reprodutions
  # POST /reprodutions.json
  def create
    @reprodution = Reprodution.new(reprodution_params)

    respond_to do |format|
      if @reprodution.save
        format.html { redirect_to @reprodution, notice: 'Reprodution was successfully created.' }
        format.json { render :show, status: :created, location: @reprodution }
      else
        format.html { render :new }
        format.json { render json: @reprodution.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /reprodutions/1
  # PATCH/PUT /reprodutions/1.json
  def update
    respond_to do |format|
      if @reprodution.update(reprodution_params)
        format.html { redirect_to @reprodution, notice: 'Reprodution was successfully updated.' }
        format.json { render :show, status: :ok, location: @reprodution }
      else
        format.html { render :edit }
        format.json { render json: @reprodution.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /reprodutions/1
  # DELETE /reprodutions/1.json
  def destroy
    @reprodution.destroy
    respond_to do |format|
      format.html { redirect_to reprodutions_url, notice: 'Reprodution was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_reprodution
      @reprodution = Reprodution.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def reprodution_params
      params.require(:reprodution).permit(:description)
    end
end
