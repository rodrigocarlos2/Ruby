class Feature < ActiveRecord::Base
	belongs_to :categorium
end
