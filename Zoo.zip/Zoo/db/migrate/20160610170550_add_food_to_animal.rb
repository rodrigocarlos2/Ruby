class AddFoodToAnimal < ActiveRecord::Migration
  def change
    add_reference :animals, :food, index: true, foreign_key: true
  end
end
