class Reprodution < ActiveRecord::Base
end
