class Animal < ActiveRecord::Base
	belongs_to :reprodution
	belongs_to :food
end
