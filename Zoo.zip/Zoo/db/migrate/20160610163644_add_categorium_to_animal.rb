class AddCategoriumToAnimal < ActiveRecord::Migration
  def change
    add_reference :animals, :categorium, index: true, foreign_key: true
  end
end
