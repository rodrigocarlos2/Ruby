class CreateReprodutions < ActiveRecord::Migration
  def change
    create_table :reprodutions do |t|
      t.string :description

      t.timestamps null: false
    end
  end
end
