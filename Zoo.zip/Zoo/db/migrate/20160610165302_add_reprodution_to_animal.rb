class AddReprodutionToAnimal < ActiveRecord::Migration
  def change
    add_reference :animals, :reprodution, index: true, foreign_key: true
  end
end
