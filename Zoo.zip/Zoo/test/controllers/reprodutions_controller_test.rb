require 'test_helper'

class ReprodutionsControllerTest < ActionController::TestCase
  setup do
    @reprodution = reprodutions(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:reprodutions)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create reprodution" do
    assert_difference('Reprodution.count') do
      post :create, reprodution: { description: @reprodution.description }
    end

    assert_redirected_to reprodution_path(assigns(:reprodution))
  end

  test "should show reprodution" do
    get :show, id: @reprodution
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @reprodution
    assert_response :success
  end

  test "should update reprodution" do
    patch :update, id: @reprodution, reprodution: { description: @reprodution.description }
    assert_redirected_to reprodution_path(assigns(:reprodution))
  end

  test "should destroy reprodution" do
    assert_difference('Reprodution.count', -1) do
      delete :destroy, id: @reprodution
    end

    assert_redirected_to reprodutions_path
  end
end
