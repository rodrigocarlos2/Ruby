class Categorium < ActiveRecord::Base
	belongs_to :planet
end
