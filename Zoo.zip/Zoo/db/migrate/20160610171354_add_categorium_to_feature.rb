class AddCategoriumToFeature < ActiveRecord::Migration
  def change
    add_reference :features, :categorium, index: true, foreign_key: true
  end
end
